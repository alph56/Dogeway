<!---->
<!DOCTYPE html>
<html>

<head>
    <title>DOGEWAY - VISION</title>
    <link rel="stylesheet" href="CSS/home.css">
</head>

<body>

    <header>

        <nav class="nav">

            <div class=ranalogo>
                <img class="rana" src="Imagenes/Rana_blanco.png">
                <div class="logo"> 
                    <a href="index.php">DOGEWAY</a>
                </div> 
            </div>

            <ul class="menu">
                <li><a href="Inicio/index.php">INICIAR SESION</a></li>
                <li><a href="Registro/registro.php">REGISTRARSE</a></li>
                <li><a>NOSOTROS</a><br>
                    <ul class="submenu">
                        <li><a href="mision.php">MISION</a></li>
                        <li><a href="vision.php">VISION</a></li>
                        <li><a href="#">CONTACTO</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
                <div class="intro">
                    <p class="centrado">
        
                    </p>
                        <h1>CONTACTO</h1><br>
                    
                        <div class="info">

                            <p>
                               
                            </p>
                            
                        </div>
                    
                    </div>
            
                </div> 
    </header>

</body>

</html>