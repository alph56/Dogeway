<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "dogeway";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Recibir parámetros desde la URL
$id1 = $_GET['id1'];
$id2 = $_GET['id2'];
$id3 = $_GET['id3'];
$id4 = $_GET['id4'];

// Actualizar el estado del match a 2
$updateQuery = "UPDATE `match` SET status = 2 WHERE (id1 = ? AND id2 = ? AND id3 = ? AND id4 = ?) OR (id1 = ? AND id2 = ? AND id3 = ? AND id4 = ?)";
$stmt = $conn->prepare($updateQuery);

// Modificar la cadena de tipos según el tipo de datos que estás manejando
$stmt->bind_param("iiiiiiii", $id1, $id2, $id3, $id4, $id2, $id1, $id4, $id3);

if ($stmt->execute()) {
    echo "Estado actualizado a 2 correctamente.";
} else {
    echo "Error al ejecutar la actualización: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
