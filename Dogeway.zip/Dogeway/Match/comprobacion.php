<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "dogeway";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta SQL para seleccionar todos los registros de la tabla match
$query = "SELECT * FROM `match`";

$result = $conn->query($query);

if ($result) {
    // Imprimir encabezados
    echo "<table border='1'>";
    echo "<tr><th>ID1</th><th>ID2</th><th>ID3</th><th>ID4</th><th>Status</th></tr>";

    // Imprimir datos de la tabla
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id1'] . "</td>";
        echo "<td>" . $row['id2'] . "</td>";
        echo "<td>" . $row['id3'] . "</td>";
        echo "<td>" . $row['id4'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";

    // Liberar el conjunto de resultados
    $result->free();
} else {
    echo "Error en la consulta: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>
