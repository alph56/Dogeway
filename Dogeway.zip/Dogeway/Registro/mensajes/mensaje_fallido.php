<!DOCTYPE html>
<html lang="en">
<head>
    <title>Verificacion de correo</title>
    <link rel="stylesheet" href="../../CSS/verificacion.css">


</head>
<body>

    <div class="mensaje">
        <br>
        <p class="texto">"Error al verificar la cuenta, revise su link</p><br>
        <p class="texto">≡(▔﹏▔)≡</p>
        <br>
    </div>
    <a class="boton" href="../../index.php">Volver</a>
    
</body>
</html>