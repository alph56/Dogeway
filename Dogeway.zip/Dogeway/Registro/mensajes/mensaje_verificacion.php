<!DOCTYPE html>
<html lang="en">
<head>
    <title>Verificacion de correo</title>
    <link rel="stylesheet" href="../../CSS/verificacion.css">
</head>
<body>

    <div class="mensaje">
        <br>
        <p class="texto">"Por favor, revisa tu correo electrónico, se ha enviado un link para verificar el usuario"</p><br>
        <p class="texto">(●'◡'●)</p>
        <br>
        
    </div>
    <a class="boton" href="../../Inicio/index.php">Volver a Inicio de Sesion</a>
    
</body>
</html>