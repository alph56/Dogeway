<!DOCTYPE html>
<html lang="en">
<head>
    <title>Verificacion de correo</title>
    <link rel="stylesheet" href="../../CSS/verificacion.css">
</head>
<body>

    <div class="mensaje">
        <br>
        <p class="texto">"Se ha verificado su cuenta con exito"</p><br>
        <p class="texto">(●'◡'●)</p>
        <br>
        
    </div>
    <a class="boton" href="../../Inicio/index.php">Iniciar Sesión</a>
    
</body>
</html>