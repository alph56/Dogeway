<?php
    $host = 'localhost';
    $bd = 'dogeway';
    $user = 'root';
    $password = "";

    $conexion = new mysqli($host, $user, $password, $bd);

    if(!$conexion){
        die("Error al conectar " . mysqli_connect_error());
    }
    
    //CONSULTAS  _________________________

    $allUsers = mysqli_query($conexion, "SELECT * FROM usuario ");

    //$chat = mysqli_query($conexion, "SELECT * FROM chat");

    //$match = mysqli_query($conexion, "SELECT * FROM match");

    $filtroMascota = 0;

    switch($filtroMascota){
      case 0:
        $allMascota = mysqli_query($conexion, "SELECT * FROM mascota");
      break;
      case 1:
        //$allMascota = mysqli_query($conexion, "SELECT * FROM mascota WHERE especie = 'perro' ");
      break;
    }
    
    //FUNCIONES _______________________________
    





    
//_____________________________TODAS LAS FUNCIONES DEL MATCH AQUI EMPIEZAN_____________________
// Función para verificar si hay un match entre dos usuarios
function checkMatch($conn, $id1, $id2) {
  // Buscar match en ambas direcciones
  $sql = "SELECT * FROM `match` WHERE (id1 = $id1 AND id2 = $id2) OR (id1 = $id2 AND id2 = $id1)";
  $result = $conn->query($sql);

  // Verificar si hay un match
  if ($result->num_rows > 0) {
      return $result->fetch_assoc();  // Devolver los datos del match
  } else {
      return false;  // No hay match
  }
}

//_____________________________FIN FUNCIONES DEL MATCH _____________________
?>